"""
Script to generate the sample Excel template with all 42 DIO objects
from the user's original configuration.
"""
import sys
import os
sys.path.insert(0, os.path.dirname(__file__))

from generator import DioObject
from excel_handler import create_template

# All 42 DIO objects from the user's example
SAMPLE_DATA = [
    DioObject("LED_1",               "PORT_PH8",  "OUT", "HIGH", "LOW_ACTIVE",  "PUSHPULL"),
    DioObject("LED_2",               "PORT_PE6",  "OUT", "HIGH", "LOW_ACTIVE",  "PUSHPULL"),
    DioObject("LED_3",               "PORT_PE7",  "OUT", "HIGH", "LOW_ACTIVE",  "PUSHPULL"),
    DioObject("LED_4",               "PORT_PI3",  "OUT", "HIGH", "LOW_ACTIVE",  "PUSHPULL"),
    DioObject("IGN1_ON_CHK",         "PORT_PD7",  "IN",  "HIGH", "LOW_ACTIVE",  "NOPULL"),
    DioObject("IGN3_ON_CHK",         "PORT_PD8",  "IN",  "HIGH", "LOW_ACTIVE",  "NOPULL"),
    DioObject("INH_PCAN_CHK",        "PORT_PI1",  "IN",  "LOW",  "HIGH_ACTIVE", "NOPULL"),
    DioObject("INH_DEBUG_CAN_CHK",   "PORT_PI0",  "IN",  "LOW",  "HIGH_ACTIVE", "NOPULL"),
    DioObject("POWER_HOLD",          "PORT_PD15", "OUT", "LOW",  "HIGH_ACTIVE", "PUSHPULL"),
    DioObject("SBC_INT",             "PORT_PF13", "IN",  "HIGH", "LOW_ACTIVE",  "NOPULL"),
    DioObject("5V_SENSOR_POWER",     "PORT_PB6",  "OUT", "HIGH", "HIGH_ACTIVE", "PUSHPULL"),
    DioObject("RSV_DI_3",            "PORT_PD4",  "IN",  "HIGH", "LOW_ACTIVE",  "NOPULL"),
    DioObject("RSV_DI_4",            "PORT_PD3",  "IN",  "HIGH", "LOW_ACTIVE",  "NOPULL"),
    DioObject("DI_MULTI_INTERRUPT",  "PORT_PG0",  "IN",  "LOW",  "HIGH_ACTIVE", "NOPULL"),
    DioObject("DRIVE_EN_SW1",        "PORT_PB4",  "IN",  "HIGH", "LOW_ACTIVE",  "NOPULL"),
    DioObject("IGN2",                "PORT_PB5",  "IN",  "LOW",  "LOW_ACTIVE",  "NOPULL",
              "//Brk2 active low 25.08.01"),
    DioObject("IGN4_RLY_FB",         "PORT_PD14", "IN",  "LOW",  "HIGH_ACTIVE", "NOPULL",
              "//PTC active low 25.08.01 //25.08.04 Ative High?"),
    DioObject("RSV_H_BRIDGE_L",      "PORT_PD10", "OUT", "LOW",  "HIGH_ACTIVE", "PUSHPULL"),
    DioObject("RSV_H_BRIDGE_R",      "PORT_PB7",  "OUT", "LOW",  "HIGH_ACTIVE", "PUSHPULL"),
    DioObject("RSV_H_BRIDGE_SEL_0",  "PORT_PD9",  "OUT", "LOW",  "HIGH_ACTIVE", "PUSHPULL"),
    DioObject("CHG_PG_L_ACT_DIR",    "PORT_PE13", "OUT", "LOW",  "HIGH_ACTIVE", "PUSHPULL"),
    DioObject("CHG_PG_L_ACT_DIS",    "PORT_PA7",  "OUT", "HIGH", "LOW_ACTIVE",  "PUSHPULL"),
    DioObject("REVERSE_LAMP_ON",     "PORT_PH12", "OUT", "LOW",  "HIGH_ACTIVE", "PUSHPULL"),
    DioObject("CHG_PG_AL_IND",       "PORT_PG10", "OUT", "LOW",  "HIGH_ACTIVE", "PUSHPULL"),
    DioObject("RVS_LP_IND_EN",       "PORT_PH11", "OUT", "LOW",  "HIGH_ACTIVE", "PUSHPULL"),
    DioObject("RVS_LP_IND_DIAG",     "PORT_PG11", "OUT", "LOW",  "HIGH_ACTIVE", "PUSHPULL"),
    DioObject("RSV_HSD_1",           "PORT_PE14", "OUT", "LOW",  "LOW_ACTIVE",  "PUSHPULL",
              "//25.08.14 --> 26.01.21 HIGH --> LOW"),
    DioObject("RSV_HSD_2",           "PORT_PA9",  "OUT", "LOW",  "HIGH_ACTIVE", "PUSHPULL"),
    DioObject("RSV_HSD12_EN",        "PORT_PG15", "OUT", "LOW",  "HIGH_ACTIVE", "PUSHPULL"),
    DioObject("RSV_HSD12_DIAG",      "PORT_PE12", "OUT", "LOW",  "HIGH_ACTIVE", "PUSHPULL"),
    DioObject("LSD_RST_B",           "PORT_PI8",  "OUT", "HIGH", "LOW_ACTIVE",  "PUSHPULL"),
    DioObject("PWMOUT_1_INH",        "PORT_PI4",  "OUT", "LOW",  "HIGH_ACTIVE", "PUSHPULL"),
    DioObject("PWMOUT_1_FAULT",      "PORT_PI5",  "IN",  "LOW",  "HIGH_ACTIVE", "NOPULL"),
    DioObject("PWMOUT_2_INH",        "PORT_PE3",  "OUT", "LOW",  "HIGH_ACTIVE", "PUSHPULL"),
    DioObject("PWMOUT_2_FAULT",      "PORT_PE2",  "IN",  "LOW",  "HIGH_ACTIVE", "NOPULL"),
    DioObject("PWMOUT_3_INH",        "PORT_PD6",  "OUT", "LOW",  "HIGH_ACTIVE", "PUSHPULL"),
    DioObject("PWMOUT_3_FAULT",      "PORT_PD5",  "IN",  "LOW",  "HIGH_ACTIVE", "NOPULL"),
    DioObject("PWMOUT_4_INH",        "PORT_PH5",  "OUT", "LOW",  "HIGH_ACTIVE", "PUSHPULL"),
    DioObject("PWMOUT_4_FAULT",      "PORT_PH4",  "IN",  "LOW",  "HIGH_ACTIVE", "NOPULL"),
    DioObject("BLDC_EN",             "PORT_PG12", "IN",  "HIGH", "LOW_ACTIVE",  "NOPULL"),
    DioObject("BLDC_DIAG",           "PORT_PG13", "IN",  "HIGH", "LOW_ACTIVE",  "NOPULL"),
    DioObject("DUMMYP41",            "PORT_ZZZ",  "IN",  "LOW",  "HIGH_ACTIVE", "NOPULL"),
]

if __name__ == "__main__":
    os.makedirs("template", exist_ok=True)
    output_path = os.path.join(os.path.dirname(__file__), "template", "ecaldio_template.xlsx")
    create_template(output_path, SAMPLE_DATA)
    print(f"Template created: {output_path}")
    print(f"Total DIO objects: {len(SAMPLE_DATA)}")
