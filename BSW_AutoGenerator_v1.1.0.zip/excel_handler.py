"""
ECAL DIO Auto Code Generator - Excel Handler
Creates, reads, and writes Excel templates for DIO configuration.
"""

from typing import List
from generator import DioObject, DIRECTIONS, INIT_STATES, POLARITIES, DIO_TYPES

try:
    from openpyxl import Workbook, load_workbook
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
    from openpyxl.utils import get_column_letter
    from openpyxl.worksheet.datavalidation import DataValidation
    HAS_OPENPYXL = True
except ImportError:
    HAS_OPENPYXL = False


# Column definitions
COLUMNS = [
    ("No", 6),
    ("Name", 28),
    ("Port Pin", 14),
    ("Direction", 12),
    ("Init State", 12),
    ("Polarity", 18),
    ("DIO Type", 14),
    ("Comment", 40),
]


def _check_openpyxl():
    if not HAS_OPENPYXL:
        raise ImportError(
            "openpyxl is required for Excel operations.\n"
            "Install it with: pip install openpyxl"
        )


def create_template(path: str, dio_list: List[DioObject] = None):
    """Create an Excel template file with optional pre-filled data."""
    _check_openpyxl()

    wb = Workbook()
    ws = wb.active
    ws.title = "ECAL DIO Config"

    # --- Styles ---
    header_font = Font(name="Consolas", size=11, bold=True, color="FFFFFF")
    header_fill = PatternFill(start_color="2F5496", end_color="2F5496", fill_type="solid")
    header_align = Alignment(horizontal="center", vertical="center")
    cell_font = Font(name="Consolas", size=10)
    cell_align = Alignment(horizontal="left", vertical="center")
    thin_border = Border(
        left=Side(style="thin"),
        right=Side(style="thin"),
        top=Side(style="thin"),
        bottom=Side(style="thin"),
    )

    # --- Header Row ---
    for col_idx, (col_name, col_width) in enumerate(COLUMNS, start=1):
        cell = ws.cell(row=1, column=col_idx, value=col_name)
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = header_align
        cell.border = thin_border
        ws.column_dimensions[get_column_letter(col_idx)].width = col_width

    # --- Data Validation (dropdowns) ---
    dv_direction = DataValidation(
        type="list",
        formula1='"' + ",".join(DIRECTIONS) + '"',
        allow_blank=False,
    )
    dv_direction.error = "Direction must be IN or OUT"
    dv_direction.errorTitle = "Invalid Direction"

    dv_init = DataValidation(
        type="list",
        formula1='"' + ",".join(INIT_STATES) + '"',
        allow_blank=False,
    )
    dv_init.error = "Init State must be HIGH or LOW"
    dv_init.errorTitle = "Invalid Init State"

    dv_polarity = DataValidation(
        type="list",
        formula1='"' + ",".join(POLARITIES) + '"',
        allow_blank=False,
    )
    dv_polarity.error = "Polarity must be LOW_ACTIVE or HIGH_ACTIVE"
    dv_polarity.errorTitle = "Invalid Polarity"

    dv_diotype = DataValidation(
        type="list",
        formula1='"' + ",".join(DIO_TYPES) + '"',
        allow_blank=False,
    )
    dv_diotype.error = "DIO Type must be PUSHPULL or NOPULL"
    dv_diotype.errorTitle = "Invalid DIO Type"

    ws.add_data_validation(dv_direction)
    ws.add_data_validation(dv_init)
    ws.add_data_validation(dv_polarity)
    ws.add_data_validation(dv_diotype)

    # Apply validation to 200 rows max
    max_rows = 200
    dv_direction.add(f"D2:D{max_rows}")
    dv_init.add(f"E2:E{max_rows}")
    dv_polarity.add(f"F2:F{max_rows}")
    dv_diotype.add(f"G2:G{max_rows}")

    # --- Fill data if provided ---
    if dio_list:
        for row_idx, dio in enumerate(dio_list, start=2):
            data = [
                row_idx - 2,          # No (0-based index)
                dio.name,
                dio.port_pin,
                dio.direction,
                dio.init_state,
                dio.polarity,
                dio.dio_type,
                dio.comment,
            ]
            for col_idx, value in enumerate(data, start=1):
                cell = ws.cell(row=row_idx, column=col_idx, value=value)
                cell.font = cell_font
                cell.alignment = cell_align
                cell.border = thin_border

    # Freeze header row
    ws.freeze_panes = "A2"

    wb.save(path)


def read_excel(path: str) -> List[DioObject]:
    """Read DIO configurations from an Excel file."""
    _check_openpyxl()

    wb = load_workbook(path)
    ws = wb.active

    dio_list = []
    for row in ws.iter_rows(min_row=2, values_only=True):
        # Skip empty rows
        if not row or not row[1]:
            continue

        # row: (No, Name, Port Pin, Direction, Init State, Polarity, DIO Type, Comment)
        name = str(row[1]).strip()
        port_pin = str(row[2]).strip() if row[2] else "PORT_ZZZ"
        direction = str(row[3]).strip() if row[3] else "IN"
        init_state = str(row[4]).strip() if row[4] else "LOW"
        polarity = str(row[5]).strip() if row[5] else "HIGH_ACTIVE"
        dio_type = str(row[6]).strip() if row[6] else "NOPULL"
        comment = str(row[7]).strip() if row[7] and str(row[7]).strip() != "None" else ""

        dio_list.append(DioObject(
            name=name,
            port_pin=port_pin,
            direction=direction,
            init_state=init_state,
            polarity=polarity,
            dio_type=dio_type,
            comment=comment,
        ))

    return dio_list


def write_excel(path: str, dio_list: List[DioObject]):
    """Write DIO configurations to an Excel file (with formatting)."""
    create_template(path, dio_list)


if __name__ == "__main__":
    # Quick test
    test_objs = [
        DioObject("LED_1", "PORT_PH8", "OUT", "HIGH", "LOW_ACTIVE", "PUSHPULL"),
        DioObject("LED_2", "PORT_PE6", "OUT", "HIGH", "LOW_ACTIVE", "PUSHPULL"),
    ]
    create_template("test_template.xlsx", test_objs)
    loaded = read_excel("test_template.xlsx")
    for d in loaded:
        print(d)
