"""
BSW_AutoGenerator - 자동 업데이트 모듈
원격 서버에서 최신 버전을 확인하고, 업데이트를 다운로드/적용합니다.

업데이트 흐름:
  1. update_config.json에서 서버 URL 읽기
  2. 원격 version.json에서 최신 버전 확인
  3. 새 버전이면 zip 다운로드 → 백업 → 압축 해제 → 파일 교체
  4. 프로그램 재시작
"""

import json
import os
import sys
import shutil
import zipfile
import tempfile
import logging
from datetime import datetime
from typing import Optional, Callable
from urllib.request import urlopen, Request
from urllib.error import URLError, HTTPError

from version import APP_VERSION, compare_versions

# --- 로깅 설정 ---
logger = logging.getLogger("updater")

# --- 경로 상수 ---
APP_DIR = os.path.dirname(os.path.abspath(__file__))
CONFIG_PATH = os.path.join(APP_DIR, "update_config.json")
BACKUP_DIR = os.path.join(APP_DIR, "_backup")

# 업데이트 대상 파일 확장자 (이 확장자만 교체)
UPDATABLE_EXTENSIONS = {".py", ".json", ".md", ".txt"}

# 업데이트에서 제외할 파일/디렉토리
EXCLUDE_FILES = {"update_config.json", "_backup", "__pycache__", ".git"}


class UpdateInfo:
    """업데이트 정보를 담는 데이터 클래스."""

    def __init__(self, has_update: bool = False, remote_version: str = "",
                 download_url: str = "", changelog: str = "",
                 min_version: str = "0.0.0", error: str = ""):
        self.has_update = has_update          # 업데이트 존재 여부
        self.remote_version = remote_version  # 원격 최신 버전
        self.download_url = download_url      # 다운로드 URL
        self.changelog = changelog            # 변경 사항 설명
        self.min_version = min_version        # 최소 지원 버전
        self.error = error                    # 에러 메시지 (실패 시)


def load_config() -> dict:
    """update_config.json 파일을 읽어 설정을 반환합니다.

    Returns:
        설정 딕셔너리. 파일이 없거나 읽기 실패 시 기본값 반환.
    """
    default_config = {
        "update_enabled": True,
        "update_url": "",
        "check_on_startup": True,
        "backup_before_update": True,
    }

    if not os.path.exists(CONFIG_PATH):
        logger.warning("update_config.json not found, using defaults")
        return default_config

    try:
        with open(CONFIG_PATH, "r", encoding="utf-8") as f:
            config = json.load(f)
        # 기본값과 병합 (누락된 키 보완)
        for key, value in default_config.items():
            config.setdefault(key, value)
        return config
    except (json.JSONDecodeError, OSError) as e:
        logger.error(f"Failed to load config: {e}")
        return default_config


def check_for_update(current_version: str = None) -> UpdateInfo:
    """원격 서버에서 최신 버전 정보를 확인합니다.

    Args:
        current_version: 현재 앱 버전 (기본값: version.py의 APP_VERSION)

    Returns:
        UpdateInfo 객체 (업데이트 존재 여부, 원격 버전, 다운로드 URL 등)
    """
    if current_version is None:
        current_version = APP_VERSION

    config = load_config()

    # 업데이트 기능 비활성화 체크
    if not config.get("update_enabled", True):
        return UpdateInfo(error="업데이트 기능이 비활성화되어 있습니다.")

    update_url = config.get("update_url", "")
    if not update_url:
        return UpdateInfo(error="업데이트 서버 URL이 설정되지 않았습니다.")

    try:
        # 원격 version.json 가져오기 (타임아웃 5초)
        req = Request(update_url, headers={"User-Agent": "BSW_AutoGenerator"})
        with urlopen(req, timeout=5) as response:
            remote_data = json.loads(response.read().decode("utf-8"))

        remote_version = remote_data.get("version", "0.0.0")
        download_url = remote_data.get("download_url", "")
        changelog = remote_data.get("changelog", "")
        min_version = remote_data.get("min_version", "0.0.0")

        # 버전 비교
        has_update = compare_versions(current_version, remote_version) < 0

        logger.info(f"Version check: current={current_version}, "
                     f"remote={remote_version}, update={'YES' if has_update else 'NO'}")

        return UpdateInfo(
            has_update=has_update,
            remote_version=remote_version,
            download_url=download_url,
            changelog=changelog,
            min_version=min_version,
        )

    except HTTPError as e:
        error_msg = f"서버 응답 오류: HTTP {e.code}"
        logger.error(error_msg)
        return UpdateInfo(error=error_msg)
    except URLError as e:
        error_msg = f"서버 연결 실패: {e.reason}"
        logger.error(error_msg)
        return UpdateInfo(error=error_msg)
    except (json.JSONDecodeError, KeyError) as e:
        error_msg = f"버전 정보 파싱 실패: {e}"
        logger.error(error_msg)
        return UpdateInfo(error=error_msg)
    except Exception as e:
        error_msg = f"업데이트 확인 중 오류: {e}"
        logger.error(error_msg)
        return UpdateInfo(error=error_msg)


def download_update(download_url: str, dest_dir: str = None,
                     progress_callback: Optional[Callable[[int, int], None]] = None) -> str:
    """업데이트 zip 파일을 다운로드합니다.

    Args:
        download_url: 다운로드할 zip 파일 URL
        dest_dir: 저장 디렉토리 (기본값: 임시 디렉토리)
        progress_callback: 진행률 콜백 함수 (received_bytes, total_bytes)

    Returns:
        다운로드된 zip 파일 경로

    Raises:
        Exception: 다운로드 실패 시
    """
    if dest_dir is None:
        dest_dir = tempfile.mkdtemp(prefix="bsw_update_")

    zip_filename = os.path.basename(download_url)
    if not zip_filename.endswith(".zip"):
        zip_filename = "update.zip"
    zip_path = os.path.join(dest_dir, zip_filename)

    logger.info(f"Downloading update from: {download_url}")

    req = Request(download_url, headers={"User-Agent": "BSW_AutoGenerator"})
    with urlopen(req, timeout=30) as response:
        total_size = int(response.headers.get("Content-Length", 0))
        received = 0
        chunk_size = 8192

        with open(zip_path, "wb") as f:
            while True:
                chunk = response.read(chunk_size)
                if not chunk:
                    break
                f.write(chunk)
                received += len(chunk)
                if progress_callback:
                    progress_callback(received, total_size)

    logger.info(f"Download complete: {zip_path} ({received} bytes)")
    return zip_path


def _create_backup() -> str:
    """현재 앱 파일들을 백업합니다.

    Returns:
        백업 디렉토리 경로
    """
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_path = os.path.join(BACKUP_DIR, f"backup_{timestamp}")
    os.makedirs(backup_path, exist_ok=True)

    for item in os.listdir(APP_DIR):
        if item in EXCLUDE_FILES or item.startswith("."):
            continue
        src = os.path.join(APP_DIR, item)
        dst = os.path.join(backup_path, item)

        if os.path.isfile(src):
            _, ext = os.path.splitext(item)
            if ext in UPDATABLE_EXTENSIONS:
                shutil.copy2(src, dst)
        elif os.path.isdir(src) and item not in {"_backup", "__pycache__", ".git"}:
            shutil.copytree(src, dst)

    logger.info(f"Backup created: {backup_path}")
    return backup_path


def apply_update(zip_path: str) -> bool:
    """다운로드된 업데이트를 적용합니다.

    Args:
        zip_path: 업데이트 zip 파일 경로

    Returns:
        True: 성공, False: 실패
    """
    config = load_config()

    try:
        # 1. 백업 생성
        if config.get("backup_before_update", True):
            backup_path = _create_backup()
            logger.info(f"Backup saved to: {backup_path}")

        # 2. 임시 디렉토리에 압축 해제
        extract_dir = tempfile.mkdtemp(prefix="bsw_extract_")
        with zipfile.ZipFile(zip_path, "r") as zf:
            zf.extractall(extract_dir)

        # 3. 압축 해제된 파일 구조 파악
        #    zip 안에 루트 폴더가 하나만 있으면 그 안의 내용을 사용
        extracted_items = os.listdir(extract_dir)
        source_dir = extract_dir
        if len(extracted_items) == 1:
            single_item = os.path.join(extract_dir, extracted_items[0])
            if os.path.isdir(single_item):
                source_dir = single_item

        # 4. 파일 교체
        updated_files = []
        for item in os.listdir(source_dir):
            if item in EXCLUDE_FILES or item.startswith("."):
                continue

            src = os.path.join(source_dir, item)
            dst = os.path.join(APP_DIR, item)

            if os.path.isfile(src):
                _, ext = os.path.splitext(item)
                if ext in UPDATABLE_EXTENSIONS:
                    shutil.copy2(src, dst)
                    updated_files.append(item)
            elif os.path.isdir(src) and item not in {"_backup", "__pycache__", ".git"}:
                # 디렉토리는 기존 것 삭제 후 복사
                if os.path.exists(dst):
                    shutil.rmtree(dst)
                shutil.copytree(src, dst)
                updated_files.append(f"{item}/")

        # 5. 임시 파일 정리
        shutil.rmtree(extract_dir, ignore_errors=True)
        if os.path.exists(zip_path):
            os.remove(zip_path)

        logger.info(f"Update applied. Files updated: {updated_files}")
        return True

    except Exception as e:
        logger.error(f"Failed to apply update: {e}")
        return False


def restore_backup(backup_name: str = None) -> bool:
    """백업에서 복원합니다.

    Args:
        backup_name: 복원할 백업 폴더 이름 (기본값: 가장 최근 백업)

    Returns:
        True: 성공, False: 실패
    """
    if not os.path.exists(BACKUP_DIR):
        logger.error("No backups found")
        return False

    backups = sorted(os.listdir(BACKUP_DIR), reverse=True)
    if not backups:
        logger.error("No backups found")
        return False

    if backup_name:
        if backup_name not in backups:
            logger.error(f"Backup not found: {backup_name}")
            return False
        target = backup_name
    else:
        target = backups[0]  # 가장 최근 백업

    backup_path = os.path.join(BACKUP_DIR, target)

    try:
        for item in os.listdir(backup_path):
            src = os.path.join(backup_path, item)
            dst = os.path.join(APP_DIR, item)

            if os.path.isfile(src):
                shutil.copy2(src, dst)
            elif os.path.isdir(src):
                if os.path.exists(dst):
                    shutil.rmtree(dst)
                shutil.copytree(src, dst)

        logger.info(f"Restored from backup: {target}")
        return True

    except Exception as e:
        logger.error(f"Failed to restore backup: {e}")
        return False


def restart_app():
    """현재 프로세스를 종료하고 앱을 재시작합니다."""
    logger.info("Restarting application...")
    python = sys.executable
    script = os.path.join(APP_DIR, "main.py")
    args = [python, script] + sys.argv[1:]

    # 현재 프로세스를 새 프로세스로 교체
    os.execv(python, args)


def perform_full_update(progress_callback: Optional[Callable[[str, int, int], None]] = None) -> tuple:
    """전체 업데이트 프로세스를 수행합니다.

    Args:
        progress_callback: 진행 상태 콜백 (stage, current, total)
            stage: "checking", "downloading", "applying", "done", "error"

    Returns:
        (success: bool, message: str)
    """
    def _notify(stage, current=0, total=0):
        if progress_callback:
            progress_callback(stage, current, total)

    # 1단계: 업데이트 확인
    _notify("checking")
    info = check_for_update()

    if info.error:
        return False, info.error

    if not info.has_update:
        return False, f"현재 최신 버전입니다. (v{APP_VERSION})"

    # 2단계: 다운로드
    _notify("downloading")
    try:
        def dl_progress(received, total):
            _notify("downloading", received, total)

        zip_path = download_update(info.download_url, progress_callback=dl_progress)
    except Exception as e:
        return False, f"다운로드 실패: {e}"

    # 3단계: 적용
    _notify("applying")
    success = apply_update(zip_path)

    if success:
        _notify("done")
        return True, f"v{info.remote_version}으로 업데이트 완료!"
    else:
        return False, "업데이트 적용 실패. 백업에서 복원해 주세요."
