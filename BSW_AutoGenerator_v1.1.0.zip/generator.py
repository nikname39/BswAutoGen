"""
ECAL DIO Auto Code Generator - Core Engine
Generates C header #define blocks from DIO object configurations.
"""
from dataclasses import dataclass, field
from typing import List, Optional
import re
# --- Constants for valid values ---
DIRECTIONS = ["IN", "OUT"]
INIT_STATES = ["HIGH", "LOW"]
POLARITIES = ["LOW_ACTIVE", "HIGH_ACTIVE"]
DIO_TYPES = ["PUSHPULL", "NOPULL"]
@dataclass
class DioObject:
    """Represents a single ECAL DIO object configuration."""
    name: str              # e.g. "LED_1"
    port_pin: str          # e.g. "PH8" → PORT_PH8
    direction: str         # "IN" or "OUT"
    init_state: str        # "HIGH" or "LOW"
    polarity: str          # "LOW_ACTIVE" or "HIGH_ACTIVE"
    dio_type: str          # "PUSHPULL" or "NOPULL"
    comment: str = ""      # Optional inline comment for INITSTATE or POLARITY line
def _tab_align(left: str, value: str, min_width: int = 40) -> str:
    """Align value using tabs (tab width = 4) so value starts at min_width column."""
    tab_width = 4
    current_len = len(left)
    # Calculate how many tabs needed
    tabs_needed = max(1, (min_width - current_len + tab_width - 1) // tab_width)
    return left + "\t" * tabs_needed + value
def generate_single_object(index: int, dio: DioObject) -> str:
    """Generate the #define block for a single DIO object."""
    lines = []
    # Comment header
    lines.append(f"/* ECAL DIO Object #{index} */")
    # Name define: #define ECALDIO_{NAME}    {index}
    name_left = f"#define ECALDIO_{dio.name}"
    lines.append(_tab_align(name_left, str(index), 40))
    # Port Pin prefix
    prefix = f"P{index}"
    # PORT_PIN
    port_value = dio.port_pin if dio.port_pin.startswith("PORT_") else f"PORT_{dio.port_pin}"
    pin_left = f"#define ECALDIO_{prefix}_PORTPIN"
    lines.append(_tab_align(pin_left, port_value, 40))
    # DIRECTION
    dir_value = f"ECALDIO_PORT_{dio.direction}"
    dir_left = f"#define ECALDIO_{prefix}_DIRECTION"
    lines.append(_tab_align(dir_left, dir_value, 40))
    # INITSTATE
    init_value = f"ECALDIO_PORT_{dio.init_state}"
    init_left = f"#define ECALDIO_{prefix}_INITSTATE"
    init_line = _tab_align(init_left, init_value, 40)
    init_comment = "\t///< Port Initial Value"
    if dio.comment:
        init_comment += f" {dio.comment}"
    lines.append(init_line + init_comment)
    # POLARITY
    pol_value = f"ECALDIO_{dio.polarity}"
    pol_left = f"#define ECALDIO_{prefix}_POLARITY"
    lines.append(_tab_align(pol_left, pol_value, 40))
    # DIOTYPE
    type_value = f"ECALDIO_DIO_{dio.dio_type}"
    type_left = f"#define ECALDIO_{prefix}_DIOTYPE"
    lines.append(_tab_align(type_left, type_value, 40))
    return "\n".join(lines)
def generate_code(dio_list: List[DioObject]) -> str:
    """Generate complete C header code from a list of DioObject."""
    blocks = []
    for i, dio in enumerate(dio_list):
        blocks.append(generate_single_object(i, dio))
    body = "\n\n".join(blocks)
    # Footer
    footer = (
        "\n\n/* !!!! Must Be Modified EcalDio_InitData(xxx); at EcalDio_Init Function !!!!! */\n"
        "/* ---------------------------- */\n"
        "/** The Maximum Number of ECAL Port */\n"
        f"#define ECALDIO_PORT_MAX\t\t\t{len(dio_list)}\t\t///< Maximum number of ECAL Port + 1\n"
        "/* ---------------------------- */\n"
    )
    return body + footer
def parse_header(code: str) -> List[DioObject]:
    """Parse existing C header code and extract DioObject list."""
    dio_list = []
    # Split into blocks by "/* ECAL DIO Object #"
    blocks = re.split(r'(?=/\*\s*ECAL DIO Object\s*#)', code)
    for block in blocks:
        block = block.strip()
        if not block.startswith("/* ECAL DIO Object"):
            continue
        # Extract name: #define ECALDIO_{NAME} {index}
        # Match lines like: #define ECALDIO_LED_1    0
        name_match = re.search(
            r'#define\s+ECALDIO_(\w+)\s+(\d+)',
            block
        )
        if not name_match:
            continue
        name = name_match.group(1)
        # Skip if this is a P{n}_ prefixed define (those are the property defines)
        if re.match(r'^P\d+_', name):
            continue
        index = int(name_match.group(2))
        # Extract PORTPIN
        portpin_match = re.search(
            r'#define\s+ECALDIO_P\d+_PORTPIN\s+(PORT_\w+|PORT_ZZZ)',
            block
        )
        port_pin = portpin_match.group(1) if portpin_match else "PORT_ZZZ"
        # Extract DIRECTION
        dir_match = re.search(
            r'#define\s+ECALDIO_P\d+_DIRECTION\s+ECALDIO_PORT_(\w+)',
            block
        )
        direction = dir_match.group(1) if dir_match else "IN"
        # Extract INITSTATE
        init_match = re.search(
            r'#define\s+ECALDIO_P\d+_INITSTATE\s+ECALDIO_PORT_(\w+)',
            block
        )
        init_state = init_match.group(1) if init_match else "LOW"
        # Extract optional comment from INITSTATE line
        comment = ""
        comment_match = re.search(
            r'#define\s+ECALDIO_P\d+_INITSTATE\s+\S+\s+///<?[^/]*Port Initial Value\s*(.*?)$',
            block, re.MULTILINE
        )
        if comment_match:
            comment = comment_match.group(1).strip()
        # Extract POLARITY
        pol_match = re.search(
            r'#define\s+ECALDIO_P\d+_POLARITY\s+ECALDIO_(\w+_ACTIVE)',
            block
        )
        polarity = pol_match.group(1) if pol_match else "HIGH_ACTIVE"
        # Extract DIOTYPE
        type_match = re.search(
            r'#define\s+ECALDIO_P\d+_DIOTYPE\s+\w*DIO_(\w+)',
            block
        )
        dio_type = type_match.group(1) if type_match else "NOPULL"
        dio_list.append(DioObject(
            name=name,
            port_pin=port_pin,
            direction=direction,
            init_state=init_state,
            polarity=polarity,
            dio_type=dio_type,
            comment=comment,
        ))
    return dio_list
if __name__ == "__main__":
    # Quick test
    test_objs = [
        DioObject("LED_1", "PORT_PH8", "OUT", "HIGH", "LOW_ACTIVE", "PUSHPULL"),
        DioObject("LED_2", "PORT_PE6", "OUT", "HIGH", "LOW_ACTIVE", "PUSHPULL"),
        DioObject("IGN1_ON_CHK", "PORT_PD7", "IN", "HIGH", "LOW_ACTIVE", "NOPULL"),
    ]
    print(generate_code(test_objs))