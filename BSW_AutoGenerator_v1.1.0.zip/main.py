"""
ECAL DIO Auto Code Generator
=============================
MCU 디지털 핀 설정(ECAL DIO)을 Excel 또는 GUI에서 입력한 뒤,
C 헤더 코드(#define 블록)를 자동 생성하는 도구입니다.

Usage:
  GUI Mode:   python main.py
  CLI Mode:   python main.py --cli input.xlsx -o output.h

Requirements:
  pip install openpyxl
"""

import argparse
import sys
import os
import logging

from version import APP_VERSION, get_version_display


def cli_mode(args):
    """Command-line mode: read Excel and generate C header code."""
    from generator import generate_code
    from excel_handler import read_excel

    if not os.path.exists(args.input):
        print(f"Error: File not found: {args.input}")
        sys.exit(1)

    print(f"Reading: {args.input}")
    dio_list = read_excel(args.input)
    print(f"Found {len(dio_list)} DIO objects.")

    code = generate_code(dio_list)

    if args.output:
        with open(args.output, "w", encoding="utf-8") as f:
            f.write(code)
        print(f"Generated: {args.output}")
    else:
        print("\n" + "=" * 60)
        print(code)
        print("=" * 60)


def cli_parse_mode(args):
    """Parse existing C header file and save to Excel."""
    from generator import parse_header
    from excel_handler import write_excel

    if not os.path.exists(args.input):
        print(f"Error: File not found: {args.input}")
        sys.exit(1)

    print(f"Parsing: {args.input}")
    with open(args.input, "r", encoding="utf-8") as f:
        code = f.read()

    dio_list = parse_header(code)
    print(f"Found {len(dio_list)} DIO objects.")

    if args.output:
        write_excel(args.output, dio_list)
        print(f"Saved to: {args.output}")
    else:
        for i, d in enumerate(dio_list):
            print(f"  #{i}: {d.name} | {d.port_pin} | {d.direction} | "
                  f"{d.init_state} | {d.polarity} | {d.dio_type}")


def cli_template_mode(args):
    """Create an empty Excel template."""
    from excel_handler import create_template

    output = args.output or "ecaldio_template.xlsx"
    create_template(output)
    print(f"Template created: {output}")


def main():
    parser = argparse.ArgumentParser(
        description="ECAL DIO Auto Code Generator",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python main.py                              # Launch GUI
  python main.py --cli input.xlsx -o output.h  # Excel → C header
  python main.py --parse header.h -o out.xlsx  # C header → Excel
  python main.py --template -o template.xlsx   # Create empty template
        """
    )

    group = parser.add_mutually_exclusive_group()
    group.add_argument("--cli", metavar="INPUT", dest="cli_input",
                       help="CLI mode: generate C code from Excel file")
    group.add_argument("--parse", metavar="INPUT", dest="parse_input",
                       help="Parse mode: extract DIO objects from C header file")
    group.add_argument("--template", action="store_true",
                       help="Create an empty Excel template")

    parser.add_argument("-o", "--output", metavar="OUTPUT",
                         help="Output file path")
    parser.add_argument("--no-update", action="store_true",
                         help="Skip auto-update check on startup")

    args = parser.parse_args()

    if args.cli_input:
        # CLI mode
        class CliArgs:
            input = args.cli_input
            output = args.output
        cli_mode(CliArgs())

    elif args.parse_input:
        # Parse mode
        class ParseArgs:
            input = args.parse_input
            output = args.output
        cli_parse_mode(ParseArgs())

    elif args.template:
        cli_template_mode(args)

    else:
        # GUI mode (default)
        if not args.no_update:
            _startup_update_check()
        from gui_app import run_gui
        run_gui()


def _startup_update_check():
    """프로그램 시작 시 업데이트를 확인합니다."""
    try:
        from updater import check_for_update, load_config

        config = load_config()
        if not config.get("check_on_startup", True):
            return
        if not config.get("update_enabled", True):
            return
        if not config.get("update_url", ""):
            return

        info = check_for_update()

        if info.has_update:
            # tkinter 다이얼로그로 업데이트 알림
            import tkinter as tk
            from tkinter import messagebox

            # 숨겨진 루트 윈도우 생성 (다이얼로그만 표시용)
            temp_root = tk.Tk()
            temp_root.withdraw()

            changelog_text = ""
            if info.changelog:
                changelog_text = f"\n\n변경 사항:\n{info.changelog}"

            msg = (
                f"새 버전을 사용할 수 있습니다!\n\n"
                f"현재 버전: v{APP_VERSION}\n"
                f"최신 버전: v{info.remote_version}"
                f"{changelog_text}\n\n"
                f"지금 업데이트 하시겠습니까?"
            )

            if messagebox.askyesno("업데이트 확인", msg, parent=temp_root):
                from updater import perform_full_update, restart_app

                success, message = perform_full_update()
                if success:
                    messagebox.showinfo("업데이트 완료", message, parent=temp_root)
                    temp_root.destroy()
                    restart_app()
                else:
                    messagebox.showerror("업데이트 실패", message, parent=temp_root)

            temp_root.destroy()

    except Exception as e:
        # 업데이트 체크 실패 시 무시하고 정상 실행
        logging.getLogger("updater").debug(f"Startup update check failed: {e}")


if __name__ == "__main__":
    main()
