"""
BSW_AutoGenerator - 버전 관리 모듈
앱 버전 정보 및 버전 비교 유틸리티를 제공합니다.
"""

# 현재 앱 버전 (Semantic Versioning: MAJOR.MINOR.PATCH)
APP_VERSION = "1.0.0"
APP_NAME = "ECAL DIO Auto Code Generator"


def parse_version(version_str: str) -> tuple:
    """버전 문자열을 (major, minor, patch) 튜플로 변환합니다.

    Args:
        version_str: "1.2.3" 형식의 버전 문자열

    Returns:
        (major, minor, patch) 정수 튜플
    """
    parts = version_str.strip().split(".")
    result = []
    for p in parts:
        # 숫자만 추출 (예: "1-beta" → 1)
        digits = ""
        for ch in p:
            if ch.isdigit():
                digits += ch
            else:
                break
        result.append(int(digits) if digits else 0)

    # 최소 3개 요소 보장
    while len(result) < 3:
        result.append(0)

    return tuple(result[:3])


def compare_versions(current: str, remote: str) -> int:
    """두 버전을 비교합니다.

    Args:
        current: 현재 버전 문자열
        remote: 원격 버전 문자열

    Returns:
        -1: current < remote (업데이트 필요)
         0: current == remote (동일 버전)
         1: current > remote (현재가 더 최신)
    """
    cur = parse_version(current)
    rem = parse_version(remote)

    if cur < rem:
        return -1
    elif cur > rem:
        return 1
    else:
        return 0


def get_version_display() -> str:
    """GUI 타이틀 등에 표시할 버전 문자열을 반환합니다."""
    return f"{APP_NAME} v{APP_VERSION}"
