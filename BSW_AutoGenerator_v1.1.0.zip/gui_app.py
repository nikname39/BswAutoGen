"""
ECAL DIO Auto Code Generator - GUI Application
tkinter-based GUI for editing DIO configurations and generating C code.
"""

import tkinter as tk
from tkinter import ttk, filedialog, messagebox, scrolledtext
import os
import sys
import threading

from generator import DioObject, generate_code, parse_header, DIRECTIONS, INIT_STATES, POLARITIES, DIO_TYPES
from version import APP_VERSION, get_version_display


# --- Color Scheme ---
BG_DARK = "#1e1e2e"
BG_MID = "#282840"
BG_LIGHT = "#313150"
FG_TEXT = "#cdd6f4"
FG_DIM = "#6c7086"
ACCENT = "#89b4fa"
ACCENT_HOVER = "#74c7ec"
GREEN = "#a6e3a1"
RED = "#f38ba8"
YELLOW = "#f9e2af"
HEADER_BG = "#2F5496"
HEADER_FG = "#ffffff"
ROW_EVEN = "#1e1e2e"
ROW_ODD = "#262640"
SELECT_BG = "#45475a"


class UpdateDialog(tk.Toplevel):
    """업데이트 진행 상태를 표시하는 다이얼로그."""

    def __init__(self, parent, remote_version: str, changelog: str):
        super().__init__(parent)
        self.title("업데이트 확인")
        self.configure(bg=BG_DARK)
        self.resizable(False, False)
        self.result = False  # True면 업데이트 수행

        self.transient(parent)
        self.grab_set()

        frame = tk.Frame(self, bg=BG_DARK, padx=30, pady=20)
        frame.pack(fill=tk.BOTH, expand=True)

        # 아이콘 + 제목
        title_lbl = tk.Label(frame, text="🔄  새 버전 발견!",
                              font=("Consolas", 14, "bold"),
                              bg=BG_DARK, fg=ACCENT)
        title_lbl.pack(anchor="w", pady=(0, 10))

        # 버전 정보
        ver_frame = tk.Frame(frame, bg=BG_MID, padx=15, pady=10)
        ver_frame.pack(fill=tk.X, pady=(0, 10))

        tk.Label(ver_frame, text=f"현재 버전:  v{APP_VERSION}",
                 font=("Consolas", 10), bg=BG_MID, fg=FG_DIM).pack(anchor="w")
        tk.Label(ver_frame, text=f"최신 버전:  v{remote_version}",
                 font=("Consolas", 10, "bold"), bg=BG_MID, fg=GREEN).pack(anchor="w")

        # 변경 사항
        if changelog:
            cl_label = tk.Label(frame, text="변경 사항:",
                                 font=("Consolas", 10, "bold"),
                                 bg=BG_DARK, fg=FG_TEXT)
            cl_label.pack(anchor="w", pady=(5, 2))

            cl_text = scrolledtext.ScrolledText(
                frame, font=("Consolas", 9),
                bg=BG_LIGHT, fg=FG_TEXT, relief="flat",
                height=6, width=50, padx=8, pady=6,
                wrap=tk.WORD, state=tk.NORMAL
            )
            cl_text.pack(fill=tk.X)
            cl_text.insert("1.0", changelog)
            cl_text.configure(state=tk.DISABLED)

        # 진행률 바 (처음에는 숨김)
        self.progress_frame = tk.Frame(frame, bg=BG_DARK)
        self.progress_label = tk.Label(self.progress_frame, text="",
                                        font=("Consolas", 9),
                                        bg=BG_DARK, fg=FG_DIM)
        self.progress_label.pack(anchor="w")
        self.progress_bar = ttk.Progressbar(self.progress_frame,
                                             mode="indeterminate", length=350)
        self.progress_bar.pack(fill=tk.X, pady=(2, 0))

        # 버튼
        self.btn_frame = tk.Frame(frame, bg=BG_DARK)
        self.btn_frame.pack(pady=(15, 0))

        self.update_btn = tk.Button(
            self.btn_frame, text="🔄 업데이트", font=("Consolas", 10, "bold"),
            bg=GREEN, fg=BG_DARK, width=12, relief="flat",
            cursor="hand2", command=self._on_update
        )
        self.update_btn.pack(side=tk.LEFT, padx=5)

        self.later_btn = tk.Button(
            self.btn_frame, text="나중에", font=("Consolas", 10),
            bg=BG_LIGHT, fg=FG_TEXT, width=12, relief="flat",
            cursor="hand2", command=self._on_later
        )
        self.later_btn.pack(side=tk.LEFT, padx=5)

        self.bind("<Escape>", lambda e: self._on_later())

        # 윈도우 크기 조정 후 중앙 배치
        self.update_idletasks()
        w = self.winfo_width()
        h = self.winfo_height()
        x = parent.winfo_x() + (parent.winfo_width() - w) // 2
        y = parent.winfo_y() + (parent.winfo_height() - h) // 2
        self.geometry(f"+{x}+{y}")

    def _on_update(self):
        self.result = True
        self.destroy()

    def _on_later(self):
        self.result = False
        self.destroy()

    def show_progress(self, text: str = "업데이트 중..."):
        """진행률 표시를 시작합니다."""
        self.update_btn.configure(state=tk.DISABLED)
        self.later_btn.configure(state=tk.DISABLED)
        self.progress_frame.pack(fill=tk.X, pady=(10, 0), before=self.btn_frame)
        self.progress_label.configure(text=text)
        self.progress_bar.start(15)

    def update_progress(self, text: str):
        """진행률 텍스트를 업데이트합니다."""
        self.progress_label.configure(text=text)


class EditDialog(tk.Toplevel):
    """Dialog for editing a single DIO object."""

    def __init__(self, parent, title="Edit DIO Object", dio: DioObject = None):
        super().__init__(parent)
        self.title(title)
        self.configure(bg=BG_DARK)
        self.resizable(False, False)
        self.result = None

        # Center on parent
        self.transient(parent)
        self.grab_set()

        # --- Fields ---
        fields = [
            ("Name:", "name"),
            ("Port Pin:", "port_pin"),
        ]
        dropdown_fields = [
            ("Direction:", "direction", DIRECTIONS),
            ("Init State:", "init_state", INIT_STATES),
            ("Polarity:", "polarity", POLARITIES),
            ("DIO Type:", "dio_type", DIO_TYPES),
        ]

        self.entries = {}
        self.combos = {}

        frame = tk.Frame(self, bg=BG_DARK, padx=20, pady=15)
        frame.pack(fill=tk.BOTH, expand=True)

        row = 0
        for label_text, key in fields:
            lbl = tk.Label(frame, text=label_text, font=("Consolas", 10),
                           bg=BG_DARK, fg=FG_TEXT, anchor="w")
            lbl.grid(row=row, column=0, sticky="w", pady=4, padx=(0, 10))

            entry = tk.Entry(frame, font=("Consolas", 10), width=30,
                             bg=BG_LIGHT, fg=FG_TEXT, insertbackground=FG_TEXT,
                             relief="flat", highlightthickness=1,
                             highlightcolor=ACCENT, highlightbackground=FG_DIM)
            entry.grid(row=row, column=1, sticky="ew", pady=4)
            self.entries[key] = entry
            row += 1

        for label_text, key, values in dropdown_fields:
            lbl = tk.Label(frame, text=label_text, font=("Consolas", 10),
                           bg=BG_DARK, fg=FG_TEXT, anchor="w")
            lbl.grid(row=row, column=0, sticky="w", pady=4, padx=(0, 10))

            combo = ttk.Combobox(frame, values=values, state="readonly",
                                 font=("Consolas", 10), width=28)
            combo.grid(row=row, column=1, sticky="ew", pady=4)
            self.combos[key] = combo
            row += 1

        # Comment field
        lbl = tk.Label(frame, text="Comment:", font=("Consolas", 10),
                       bg=BG_DARK, fg=FG_TEXT, anchor="w")
        lbl.grid(row=row, column=0, sticky="w", pady=4, padx=(0, 10))

        self.comment_entry = tk.Entry(frame, font=("Consolas", 10), width=30,
                                       bg=BG_LIGHT, fg=FG_TEXT, insertbackground=FG_TEXT,
                                       relief="flat", highlightthickness=1,
                                       highlightcolor=ACCENT, highlightbackground=FG_DIM)
        self.comment_entry.grid(row=row, column=1, sticky="ew", pady=4)
        row += 1

        # --- Fill existing values ---
        if dio:
            self.entries["name"].insert(0, dio.name)
            self.entries["port_pin"].insert(0, dio.port_pin)
            self.combos["direction"].set(dio.direction)
            self.combos["init_state"].set(dio.init_state)
            self.combos["polarity"].set(dio.polarity)
            self.combos["dio_type"].set(dio.dio_type)
            self.comment_entry.insert(0, dio.comment)
        else:
            self.combos["direction"].set("OUT")
            self.combos["init_state"].set("LOW")
            self.combos["polarity"].set("HIGH_ACTIVE")
            self.combos["dio_type"].set("PUSHPULL")

        # --- Buttons ---
        btn_frame = tk.Frame(frame, bg=BG_DARK)
        btn_frame.grid(row=row, column=0, columnspan=2, pady=(15, 0))

        ok_btn = tk.Button(btn_frame, text="OK", font=("Consolas", 10, "bold"),
                           bg=ACCENT, fg=BG_DARK, width=10, relief="flat",
                           cursor="hand2", command=self._on_ok)
        ok_btn.pack(side=tk.LEFT, padx=5)

        cancel_btn = tk.Button(btn_frame, text="Cancel", font=("Consolas", 10),
                               bg=BG_LIGHT, fg=FG_TEXT, width=10, relief="flat",
                               cursor="hand2", command=self.destroy)
        cancel_btn.pack(side=tk.LEFT, padx=5)

        # Bind Enter key
        self.bind("<Return>", lambda e: self._on_ok())
        self.bind("<Escape>", lambda e: self.destroy())

        self.wait_window(self)

    def _on_ok(self):
        name = self.entries["name"].get().strip()
        port_pin = self.entries["port_pin"].get().strip()

        if not name:
            messagebox.showwarning("Warning", "Name is required.", parent=self)
            return
        if not port_pin:
            messagebox.showwarning("Warning", "Port Pin is required.", parent=self)
            return

        self.result = DioObject(
            name=name,
            port_pin=port_pin,
            direction=self.combos["direction"].get(),
            init_state=self.combos["init_state"].get(),
            polarity=self.combos["polarity"].get(),
            dio_type=self.combos["dio_type"].get(),
            comment=self.comment_entry.get().strip(),
        )
        self.destroy()


class DioGeneratorApp:
    """Main GUI Application."""

    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title(get_version_display())
        self.root.configure(bg=BG_DARK)
        self.root.geometry("1200x750")
        self.root.minsize(900, 600)

        self.dio_list: list[DioObject] = []

        self._setup_styles()
        self._create_menu()
        self._create_toolbar()
        self._create_main_area()
        self._create_statusbar()

    def _setup_styles(self):
        style = ttk.Style()
        style.theme_use("clam")

        style.configure("Treeview",
                         background=BG_DARK,
                         foreground=FG_TEXT,
                         fieldbackground=BG_DARK,
                         font=("Consolas", 10),
                         rowheight=26,
                         borderwidth=0)
        style.configure("Treeview.Heading",
                         background=HEADER_BG,
                         foreground=HEADER_FG,
                         font=("Consolas", 10, "bold"),
                         borderwidth=1,
                         relief="flat")
        style.map("Treeview",
                   background=[("selected", SELECT_BG)],
                   foreground=[("selected", ACCENT)])
        style.map("Treeview.Heading",
                   background=[("active", "#3a6bc5")])

        style.configure("TNotebook", background=BG_DARK, borderwidth=0)
        style.configure("TNotebook.Tab",
                         background=BG_MID,
                         foreground=FG_TEXT,
                         font=("Consolas", 10),
                         padding=[12, 6])
        style.map("TNotebook.Tab",
                   background=[("selected", ACCENT)],
                   foreground=[("selected", BG_DARK)])

    def _create_menu(self):
        menubar = tk.Menu(self.root, bg=BG_MID, fg=FG_TEXT, font=("Consolas", 10),
                          activebackground=ACCENT, activeforeground=BG_DARK,
                          relief="flat", borderwidth=0)

        # File menu
        file_menu = tk.Menu(menubar, tearoff=0, bg=BG_MID, fg=FG_TEXT,
                            activebackground=ACCENT, activeforeground=BG_DARK,
                            font=("Consolas", 10))
        file_menu.add_command(label="📂 Open Excel...", command=self._open_excel)
        file_menu.add_command(label="💾 Save Excel...", command=self._save_excel)
        file_menu.add_separator()
        file_menu.add_command(label="📄 Open C Header...", command=self._open_header)
        file_menu.add_command(label="📝 Save C Header...", command=self._save_header)
        file_menu.add_separator()
        file_menu.add_command(label="📋 Create Excel Template...", command=self._create_template)
        file_menu.add_separator()
        file_menu.add_command(label="❌ Exit", command=self.root.quit)
        menubar.add_cascade(label="File", menu=file_menu)

        # Edit menu
        edit_menu = tk.Menu(menubar, tearoff=0, bg=BG_MID, fg=FG_TEXT,
                            activebackground=ACCENT, activeforeground=BG_DARK,
                            font=("Consolas", 10))
        edit_menu.add_command(label="➕ Add DIO Object", command=self._add_row)
        edit_menu.add_command(label="✏️ Edit Selected", command=self._edit_row)
        edit_menu.add_command(label="🗑️ Delete Selected", command=self._delete_row)
        edit_menu.add_separator()
        edit_menu.add_command(label="⬆️ Move Up", command=self._move_up)
        edit_menu.add_command(label="⬇️ Move Down", command=self._move_down)
        edit_menu.add_separator()
        edit_menu.add_command(label="🧹 Clear All", command=self._clear_all)
        menubar.add_cascade(label="Edit", menu=edit_menu)

        # Help menu (업데이트 확인 포함)
        help_menu = tk.Menu(menubar, tearoff=0, bg=BG_MID, fg=FG_TEXT,
                            activebackground=ACCENT, activeforeground=BG_DARK,
                            font=("Consolas", 10))
        help_menu.add_command(label="🔄 업데이트 확인...", command=self._check_update_manual)
        help_menu.add_separator()
        help_menu.add_command(label=f"ℹ️ 버전 정보 (v{APP_VERSION})",
                              command=self._show_about)
        menubar.add_cascade(label="Help", menu=help_menu)

        self.root.config(menu=menubar)

    def _make_btn(self, parent, text, command, bg=BG_LIGHT, fg=FG_TEXT):
        btn = tk.Button(parent, text=text, font=("Consolas", 9),
                        bg=bg, fg=fg, relief="flat", padx=10, pady=4,
                        cursor="hand2", activebackground=ACCENT,
                        activeforeground=BG_DARK, command=command)
        btn.pack(side=tk.LEFT, padx=3, pady=4)
        return btn

    def _create_toolbar(self):
        toolbar = tk.Frame(self.root, bg=BG_MID, padx=5, pady=2)
        toolbar.pack(fill=tk.X)

        self._make_btn(toolbar, "📂 Open Excel", self._open_excel)
        self._make_btn(toolbar, "💾 Save Excel", self._save_excel)

        sep = tk.Frame(toolbar, width=2, bg=FG_DIM)
        sep.pack(side=tk.LEFT, fill=tk.Y, padx=8, pady=4)

        self._make_btn(toolbar, "➕ Add", self._add_row, bg=GREEN, fg=BG_DARK)
        self._make_btn(toolbar, "✏️ Edit", self._edit_row)
        self._make_btn(toolbar, "🗑️ Delete", self._delete_row, bg=RED, fg=BG_DARK)
        self._make_btn(toolbar, "⬆️ Up", self._move_up)
        self._make_btn(toolbar, "⬇️ Down", self._move_down)

        sep2 = tk.Frame(toolbar, width=2, bg=FG_DIM)
        sep2.pack(side=tk.LEFT, fill=tk.Y, padx=8, pady=4)

        self._make_btn(toolbar, "⚡ Generate Code", self._generate_code,
                       bg=ACCENT, fg=BG_DARK)

    def _create_main_area(self):
        # Use PanedWindow for resizable split
        paned = tk.PanedWindow(self.root, orient=tk.VERTICAL,
                                bg=BG_DARK, sashwidth=4, sashrelief="flat")
        paned.pack(fill=tk.BOTH, expand=True, padx=5, pady=(2, 0))

        # --- Top: Table ---
        table_frame = tk.Frame(paned, bg=BG_DARK)

        columns = ("no", "name", "port_pin", "direction", "init_state",
                    "polarity", "dio_type", "comment")
        self.tree = ttk.Treeview(table_frame, columns=columns, show="headings",
                                  selectmode="browse")

        col_widths = {
            "no": 50, "name": 200, "port_pin": 110, "direction": 80,
            "init_state": 80, "polarity": 130, "dio_type": 100, "comment": 250
        }
        col_headers = {
            "no": "No", "name": "Name", "port_pin": "Port Pin",
            "direction": "Dir", "init_state": "Init",
            "polarity": "Polarity", "dio_type": "DIO Type", "comment": "Comment"
        }
        for col in columns:
            self.tree.heading(col, text=col_headers[col])
            anchor = "center" if col in ("no", "direction", "init_state") else "w"
            self.tree.column(col, width=col_widths[col], anchor=anchor)

        # Scrollbar
        vsb = ttk.Scrollbar(table_frame, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=vsb.set)

        self.tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        vsb.pack(side=tk.RIGHT, fill=tk.Y)

        # Double-click to edit
        self.tree.bind("<Double-1>", lambda e: self._edit_row())

        # Tag for alternating row colors
        self.tree.tag_configure("even", background=ROW_EVEN)
        self.tree.tag_configure("odd", background=ROW_ODD)

        paned.add(table_frame, height=350)

        # --- Bottom: Code Preview ---
        preview_frame = tk.Frame(paned, bg=BG_DARK)

        preview_label = tk.Label(preview_frame, text="  Generated Code Preview",
                                  font=("Consolas", 10, "bold"),
                                  bg=BG_MID, fg=ACCENT, anchor="w", padx=10, pady=4)
        preview_label.pack(fill=tk.X)

        self.code_text = scrolledtext.ScrolledText(
            preview_frame, font=("Consolas", 10),
            bg="#0d1117", fg="#e6edf3", insertbackground=FG_TEXT,
            relief="flat", wrap=tk.NONE, padx=10, pady=8,
            selectbackground=SELECT_BG, selectforeground=ACCENT
        )
        self.code_text.pack(fill=tk.BOTH, expand=True)

        # Horizontal scrollbar for code
        xsb = ttk.Scrollbar(preview_frame, orient="horizontal",
                             command=self.code_text.xview)
        self.code_text.configure(xscrollcommand=xsb.set)
        xsb.pack(fill=tk.X)

        paned.add(preview_frame, height=300)

    def _create_statusbar(self):
        self.statusbar = tk.Label(self.root, text=f"  Ready  |  0 DIO Objects  |  v{APP_VERSION}",
                                   font=("Consolas", 9),
                                   bg=BG_MID, fg=FG_DIM, anchor="w",
                                   padx=10, pady=3)
        self.statusbar.pack(fill=tk.X, side=tk.BOTTOM)

    def _update_status(self, msg: str = ""):
        count = len(self.dio_list)
        text = f"  {msg}  |  " if msg else "  Ready  |  "
        text += f"{count} DIO Objects  |  v{APP_VERSION}"
        self.statusbar.config(text=text)

    def _refresh_table(self):
        """Refresh the treeview from dio_list."""
        self.tree.delete(*self.tree.get_children())
        for i, dio in enumerate(self.dio_list):
            tag = "even" if i % 2 == 0 else "odd"
            self.tree.insert("", "end", values=(
                i, dio.name, dio.port_pin, dio.direction,
                dio.init_state, dio.polarity, dio.dio_type, dio.comment
            ), tags=(tag,))
        self._update_status()

    def _get_selected_index(self) -> int:
        sel = self.tree.selection()
        if not sel:
            return -1
        item = self.tree.item(sel[0])
        return int(item["values"][0])

    # --- Row Operations ---

    def _add_row(self):
        dlg = EditDialog(self.root, title="Add DIO Object")
        if dlg.result:
            self.dio_list.append(dlg.result)
            self._refresh_table()
            self._update_status("Added")

    def _edit_row(self):
        idx = self._get_selected_index()
        if idx < 0:
            messagebox.showinfo("Info", "Please select a row to edit.", parent=self.root)
            return
        dio = self.dio_list[idx]
        dlg = EditDialog(self.root, title=f"Edit DIO Object #{idx}", dio=dio)
        if dlg.result:
            self.dio_list[idx] = dlg.result
            self._refresh_table()
            self._update_status("Updated")

    def _delete_row(self):
        idx = self._get_selected_index()
        if idx < 0:
            messagebox.showinfo("Info", "Please select a row to delete.", parent=self.root)
            return
        if messagebox.askyesno("Confirm", f"Delete DIO Object #{idx} ({self.dio_list[idx].name})?",
                               parent=self.root):
            del self.dio_list[idx]
            self._refresh_table()
            self._update_status("Deleted")

    def _move_up(self):
        idx = self._get_selected_index()
        if idx <= 0:
            return
        self.dio_list[idx], self.dio_list[idx - 1] = self.dio_list[idx - 1], self.dio_list[idx]
        self._refresh_table()
        # Re-select the moved item
        children = self.tree.get_children()
        if idx - 1 < len(children):
            self.tree.selection_set(children[idx - 1])

    def _move_down(self):
        idx = self._get_selected_index()
        if idx < 0 or idx >= len(self.dio_list) - 1:
            return
        self.dio_list[idx], self.dio_list[idx + 1] = self.dio_list[idx + 1], self.dio_list[idx]
        self._refresh_table()
        children = self.tree.get_children()
        if idx + 1 < len(children):
            self.tree.selection_set(children[idx + 1])

    def _clear_all(self):
        if self.dio_list:
            if messagebox.askyesno("Confirm", "Clear all DIO objects?", parent=self.root):
                self.dio_list.clear()
                self._refresh_table()
                self.code_text.delete("1.0", tk.END)
                self._update_status("Cleared")

    # --- File Operations ---

    def _open_excel(self):
        try:
            from excel_handler import read_excel
        except ImportError:
            messagebox.showerror("Error",
                                 "openpyxl is required.\nInstall: pip install openpyxl",
                                 parent=self.root)
            return

        path = filedialog.askopenfilename(
            title="Open Excel File",
            filetypes=[("Excel Files", "*.xlsx"), ("All Files", "*.*")],
            parent=self.root
        )
        if path:
            try:
                self.dio_list = read_excel(path)
                self._refresh_table()
                self._update_status(f"Loaded from {os.path.basename(path)}")
            except Exception as e:
                messagebox.showerror("Error", f"Failed to read Excel:\n{e}",
                                     parent=self.root)

    def _save_excel(self):
        try:
            from excel_handler import write_excel
        except ImportError:
            messagebox.showerror("Error",
                                 "openpyxl is required.\nInstall: pip install openpyxl",
                                 parent=self.root)
            return

        if not self.dio_list:
            messagebox.showwarning("Warning", "No DIO objects to save.", parent=self.root)
            return

        path = filedialog.asksaveasfilename(
            title="Save Excel File",
            defaultextension=".xlsx",
            filetypes=[("Excel Files", "*.xlsx")],
            parent=self.root
        )
        if path:
            try:
                write_excel(path, self.dio_list)
                self._update_status(f"Saved to {os.path.basename(path)}")
            except Exception as e:
                messagebox.showerror("Error", f"Failed to save Excel:\n{e}",
                                     parent=self.root)

    def _open_header(self):
        path = filedialog.askopenfilename(
            title="Open C Header File",
            filetypes=[("Header Files", "*.h"), ("C Files", "*.c"), ("All Files", "*.*")],
            parent=self.root
        )
        if path:
            try:
                with open(path, "r", encoding="utf-8") as f:
                    code = f.read()
                self.dio_list = parse_header(code)
                self._refresh_table()
                self._update_status(f"Parsed from {os.path.basename(path)}")
            except Exception as e:
                messagebox.showerror("Error", f"Failed to parse header:\n{e}",
                                     parent=self.root)

    def _save_header(self):
        if not self.dio_list:
            messagebox.showwarning("Warning", "No DIO objects to save.", parent=self.root)
            return

        path = filedialog.asksaveasfilename(
            title="Save C Header File",
            defaultextension=".h",
            filetypes=[("Header Files", "*.h"), ("C Files", "*.c"), ("All Files", "*.*")],
            parent=self.root
        )
        if path:
            try:
                code = generate_code(self.dio_list)
                with open(path, "w", encoding="utf-8") as f:
                    f.write(code)
                self._update_status(f"Saved to {os.path.basename(path)}")
            except Exception as e:
                messagebox.showerror("Error", f"Failed to save header:\n{e}",
                                     parent=self.root)

    def _create_template(self):
        try:
            from excel_handler import create_template
        except ImportError:
            messagebox.showerror("Error",
                                 "openpyxl is required.\nInstall: pip install openpyxl",
                                 parent=self.root)
            return

        path = filedialog.asksaveasfilename(
            title="Create Excel Template",
            defaultextension=".xlsx",
            initialfile="ecaldio_template.xlsx",
            filetypes=[("Excel Files", "*.xlsx")],
            parent=self.root
        )
        if path:
            try:
                create_template(path)
                self._update_status(f"Template created: {os.path.basename(path)}")
                messagebox.showinfo("Success",
                                    f"Empty template created:\n{path}",
                                    parent=self.root)
            except Exception as e:
                messagebox.showerror("Error", f"Failed to create template:\n{e}",
                                     parent=self.root)

    # --- Code Generation ---

    def _generate_code(self):
        if not self.dio_list:
            messagebox.showwarning("Warning", "No DIO objects to generate.", parent=self.root)
            return

        code = generate_code(self.dio_list)
        self.code_text.delete("1.0", tk.END)
        self.code_text.insert("1.0", code)
        self._update_status("Code generated")

    # --- Update Operations ---

    def _check_update_manual(self):
        """Help 메뉴에서 수동으로 업데이트를 확인합니다."""
        self._update_status("업데이트 확인 중...")
        self.root.update_idletasks()

        def _do_check():
            try:
                from updater import check_for_update
                info = check_for_update()
                self.root.after(0, lambda: self._handle_update_result(info))
            except Exception as e:
                self.root.after(0, lambda: self._handle_update_error(str(e)))

        # 별도 스레드에서 업데이트 확인 (GUI 블로킹 방지)
        thread = threading.Thread(target=_do_check, daemon=True)
        thread.start()

    def _handle_update_result(self, info):
        """업데이트 확인 결과를 처리합니다."""
        if info.error:
            self._update_status(f"업데이트 확인 실패")
            messagebox.showwarning("업데이트 확인",
                                    f"업데이트를 확인할 수 없습니다.\n\n{info.error}",
                                    parent=self.root)
            return

        if not info.has_update:
            self._update_status("최신 버전")
            messagebox.showinfo("업데이트 확인",
                                 f"현재 최신 버전입니다. (v{APP_VERSION})",
                                 parent=self.root)
            return

        # 업데이트 다이얼로그 표시
        dlg = UpdateDialog(self.root, info.remote_version, info.changelog)
        dlg.wait_window(dlg)

        if dlg.result:
            self._perform_update_in_thread()

    def _handle_update_error(self, error_msg):
        """업데이트 확인 에러를 처리합니다."""
        self._update_status("업데이트 확인 실패")
        messagebox.showerror("오류",
                              f"업데이트 확인 중 오류가 발생했습니다.\n\n{error_msg}",
                              parent=self.root)

    def _perform_update_in_thread(self):
        """별도 스레드에서 업데이트를 수행합니다."""
        self._update_status("업데이트 다운로드 중...")
        self.root.update_idletasks()

        def _do_update():
            try:
                from updater import perform_full_update, restart_app

                def progress_cb(stage, current, total):
                    stage_text = {
                        "checking": "업데이트 확인 중...",
                        "downloading": f"다운로드 중... ({current // 1024}KB)" if total else "다운로드 중...",
                        "applying": "업데이트 적용 중...",
                        "done": "업데이트 완료!",
                        "error": "업데이트 실패",
                    }
                    text = stage_text.get(stage, stage)
                    self.root.after(0, lambda: self._update_status(text))

                success, message = perform_full_update(progress_callback=progress_cb)

                if success:
                    def _on_success():
                        messagebox.showinfo("업데이트 완료",
                                             f"{message}\n\n프로그램을 재시작합니다.",
                                             parent=self.root)
                        restart_app()
                    self.root.after(0, _on_success)
                else:
                    self.root.after(0, lambda: messagebox.showerror(
                        "업데이트 실패", message, parent=self.root))
                    self.root.after(0, lambda: self._update_status("업데이트 실패"))

            except Exception as e:
                self.root.after(0, lambda: messagebox.showerror(
                    "오류", f"업데이트 중 오류:\n{e}", parent=self.root))
                self.root.after(0, lambda: self._update_status(""))

        thread = threading.Thread(target=_do_update, daemon=True)
        thread.start()

    def _show_about(self):
        """앱 정보 다이얼로그를 표시합니다."""
        messagebox.showinfo(
            "ECAL DIO Auto Code Generator",
            f"Version: v{APP_VERSION}\n\n"
            f"MCU 디지털 핀 설정(ECAL DIO)을\n"
            f"Excel 또는 GUI에서 입력하여\n"
            f"C 헤더 코드를 자동 생성합니다.",
            parent=self.root
        )


def run_gui():
    """Launch the GUI application."""
    root = tk.Tk()

    # Set window icon if available
    try:
        root.iconbitmap(default="")
    except Exception:
        pass

    app = DioGeneratorApp(root)
    root.mainloop()


if __name__ == "__main__":
    run_gui()
